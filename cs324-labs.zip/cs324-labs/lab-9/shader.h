#ifndef SHADER_H

#include "demo.h"
#include "textfile.h"

void setShaders(const char* vsname, const char* fsname);

#endif
